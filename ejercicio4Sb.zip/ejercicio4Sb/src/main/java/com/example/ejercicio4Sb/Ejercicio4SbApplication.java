package com.example.ejercicio4Sb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;



@SpringBootApplication
public class Ejercicio4SbApplication {


	public static ArrayList<ParCiudadHabs> ciudades_y_habitantes = new ArrayList<ParCiudadHabs>();

	@Autowired
	private static Implementadora implementadora;



	public static void main(String[] args)
	{
		//Crea la lista ArrayList
		implementadora.crearListaCiudades(ciudades_y_habitantes);

		System.out.println("\n\n" + "ArrayList ciudades creada al iniciar ejecución.");
		System.out.println("Se añadirán objetos 'ParCiudadHabs' compuestos por pareja 'String ciudad' + 'int numHabs' ");

		//Añade un primer elemento
		ciudades_y_habitantes.add(new ParCiudadHabs("Barcelona", 50000));
		//System.out.println("Añadido primer objeto: 'Barcelona 1600000': " + ciudades_y_habitantes.get(0));

		//Lo recupero
		//System.out.println("Tras crear ArrayList.  Elemento 0 leído desde main: " + ciudades_y_habitantes.get(0));

		SpringApplication.run(Ejercicio4SbApplication.class, args);

	}
}