package com.example.ejercicio4Sb;

import java.util.ArrayList;

public interface IgetSetCiudadesHabsService {

    ArrayList getLista();
    void addToList(ParCiudadHabs pch);

}
