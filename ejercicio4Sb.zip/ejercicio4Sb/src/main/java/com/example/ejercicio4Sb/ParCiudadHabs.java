package com.example.ejercicio4Sb;


// Para poder guardar en el ArrayList objetos compuestos de "Ciudad + numHabitantes"
public class ParCiudadHabs
{
    ParCiudadHabs(String ciudadIn, int habsIn){
        this.ciudad = ciudadIn;
        this.numHabs = habsIn;
    }

    ParCiudadHabs() { }

    public String getCiudad() {
        return ciudad;
    }
    public int getNumHabs() {
        return numHabs;
    }

    public void setCiudad(String ciudad) { this.ciudad = ciudad; }
    public void setNumHabs(int numHabs) { this.numHabs = numHabs; }


    public ParCiudadHabs crearObjetoParCiudadHabs(String ciudadIn, int numHabsIn)
    {
        return new ParCiudadHabs(ciudadIn,numHabsIn);
    }

    String ciudad = "";
    int numHabs = 0;

}
