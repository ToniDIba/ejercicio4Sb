package com.example.ejercicio4Sb;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import java.util.Iterator;

@RestController
public class Controlador2 {

    @Autowired
    private Implementadora implementadora2;


    // http://localhost:8080/controlador2/getCiudad
    @GetMapping("/controlador2/getCiudad")
    public ArrayList controlador2 () {


        Iterator<ParCiudadHabs> it= implementadora2.getLista().iterator();
        while(it.hasNext()) {

            ParCiudadHabs aux;
            aux = it.next();
            System.out.println("Controlador 2. Leído item de ArrayList. Ciudad: " + aux.getCiudad() + " Num habitantes: " + aux.getNumHabs() );
        }

        return implementadora2.getLista();
    }


}
