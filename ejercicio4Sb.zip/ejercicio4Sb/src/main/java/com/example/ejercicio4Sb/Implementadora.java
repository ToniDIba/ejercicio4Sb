package com.example.ejercicio4Sb;

import java.util.ArrayList;




public class Implementadora implements IgetSetCiudadesHabsService {

    public static ArrayList<ParCiudadHabs> ciudades_y_habitantes_List;


    ParCiudadHabs mipc = new ParCiudadHabs(); //Objeto pareja: "Ciudad" + "número habitantes" para guardar en la lista

    public static void crearListaCiudades(ArrayList listaIn) { ciudades_y_habitantes_List = listaIn; }

    //Añadir elemento "ciudad+numHabs" a la lista
    public void addToList(ParCiudadHabs pch) { ciudades_y_habitantes_List.add(pch); }

    //Retornar lista
    public ArrayList getLista() { return ciudades_y_habitantes_List; };


}