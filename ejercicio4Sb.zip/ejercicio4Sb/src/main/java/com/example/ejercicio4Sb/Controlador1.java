package com.example.ejercicio4Sb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;


@RestController
public class Controlador1
{

    @Bean
    Implementadora getImplementadora() { return new Implementadora(); }

    @Autowired
    private Implementadora implementadora;


    //http://localhost:8080/controlador1/addCiudad/?ciudad=Sarria&numHabs=20000
    @PostMapping("/controlador1/addCiudad")
    public ArrayList controlador1 (@RequestParam(name = "ciudad") String ciudad,
                                   @RequestParam(name = "numHabs") int numHabs)
    {

        //System.out.println("Ciudad     parametro leído: " + ciudad);
        //System.out.println("Habitantes parametro leído: " + numHabs);

        int aux = Integer.valueOf(numHabs);

        ParCiudadHabs miPar;
        miPar = implementadora.mipc.crearObjetoParCiudadHabs(ciudad, aux);

        //Añado pareja Ciudad-numHabs a la lista
        implementadora.addToList(miPar);

        //System.out.println("Controlador1. Lista item 0: " + implementadora.getLista().get(0).toString());
        //System.out.println("Controlador1. Lista item 1: " + implementadora.getLista().get(1).toString());

        return implementadora.getLista();

    }


}
