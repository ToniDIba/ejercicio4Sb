package com.example.ejercicio4Sb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio4SbApplicationTests {

	@Test
	void contextLoads() {
	}

}
